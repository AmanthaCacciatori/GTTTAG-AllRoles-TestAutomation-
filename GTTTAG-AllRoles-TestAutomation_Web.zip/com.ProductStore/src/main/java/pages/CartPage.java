//class referring to cart which has the abstraction of the test class and is responsible for the interface with Selenium//

package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class CartPage {

	private WebDriver driver;

	private By productName = By.cssSelector("");
	private By productPrice = By.cssSelector("");
	private By subtotalCart = By.cssSelector("");
	private By proceedToCheckoutButton = By.cssSelector("");

	public CartPage(WebDriver driver) {
		this.driver = driver;
	}

	public String getProductName() {
		return driver.findElement(productName).getText();
	}

	public String getSubtotalCart() {
		return driver.findElement(subtotalCart).getText();
	}

	public CheckoutPage clickProceedToCheckoutButton() {
		driver.findElement(proceedToCheckoutButton).click();
		return new CheckoutPage(driver);
	}

}
