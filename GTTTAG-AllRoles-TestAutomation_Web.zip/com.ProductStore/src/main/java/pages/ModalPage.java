//class referring to order confirm which has the abstraction of the test class and is responsible for the interface with Selenium//


package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ModalPage {

	private WebDriver driver;

	private By productPrice = By.cssSelector("");

	private By subtotal = By.cssSelector("");

	private By botaoProceedToCheckout = By.cssSelector("");

	public ModalPage(WebDriver driver) {
		this.driver = driver;
	}

	public String getProductPrice() {
		return driver.findElement(productPrice).getText();
	}

	public String getSubtotalOrder() {
		return driver.findElement(subtotal).getText();
	}

	public CartPage clickProceedToCheckoutButton() {
		driver.findElement(botaoProceedToCheckout).click();
		return new CartPage(driver);
	}
}
