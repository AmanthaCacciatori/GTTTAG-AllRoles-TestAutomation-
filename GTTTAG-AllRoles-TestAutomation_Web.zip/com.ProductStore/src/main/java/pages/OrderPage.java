
//class referring to order which has the abstraction of the test class and is responsible for the interface with Selenium//


package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OrderPage {

	private WebDriver driver;
	private By confirmedOrderPopup = By.cssSelector("");
	
	public OrderPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public String getConfirmedOrder() {
		return driver.findElement(confirmedOrderPopup).getText();
	}
	
	
}
