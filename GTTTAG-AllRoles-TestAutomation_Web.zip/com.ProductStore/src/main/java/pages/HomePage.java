//class referring to home page which has the abstraction of the test class and is responsible for the interface with Selenium//



package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


public class HomePage {

	private WebDriver driver;

	List<WebElement> productsList = new ArrayList();
	private By productName = By.className("");
	private By productPrice = By.className("");

	public HomePage(WebDriver driver) {

		this.driver = driver;
	}

	public void selectProduct() {

		navigatingCategories();
		// implementaci�n del m�todo

	}

	public void navigatingCategories() {
		WebElement selectElement = driver.findElement(By.cssSelector("list-group-item"));
		Select selectObject = new Select(selectElement);
		selectObject.selectByVisibleText("Phones");

		WebElement selectElement2 = driver.findElement(By.cssSelector("list-group-item"));
		Select selectObject2 = new Select(selectElement);
		selectObject2.selectByVisibleText("Laptops");

	}

	public String getProductName(int index) {
		return driver.findElements(productName).get(index).getText();

	}

	public String getProductPrice(int index) {
		return driver.findElements(productPrice).get(index).getText();
	}

	public ProductPage clickProduct(int index) {
		driver.findElements(productName).get(index).click();
		return new ProductPage(driver);
	}

}
