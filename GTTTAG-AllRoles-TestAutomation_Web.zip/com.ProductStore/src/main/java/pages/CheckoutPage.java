//class referring to checkout which has the abstraction of the test class and is responsible for the interface with Selenium//


package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
	
	private WebDriver driver;
	
	private By proceedToOrderButton = By.cssSelector("");

	
	
	public CheckoutPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public OrderPage clickToProceedOrder() {
		driver.findElement(proceedToOrderButton).click();
		return new OrderPage(driver);
	}

}
