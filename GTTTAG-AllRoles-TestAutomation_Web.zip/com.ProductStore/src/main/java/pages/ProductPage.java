//class referring to products which has the abstraction of the test class and is responsible for the interface with Selenium//


package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {

	private WebDriver driver;

	private By productName = By.className("");
	private By productPrice = By.cssSelector("");
	private By addCartButton = By.className("");

	public ProductPage(WebDriver driver) {
		this.driver = driver;
	}

	public String getProductName( ) {
		return driver.findElement(productName).getText();
	}
		
	public String getProductPrice(){
		return driver.findElement(productPrice).getText();
		}

	public ModalPage clickProceedToCheckoutButton() {
		driver.findElement(addCartButton).click();
		return new ModalPage(driver);
		}
	}



