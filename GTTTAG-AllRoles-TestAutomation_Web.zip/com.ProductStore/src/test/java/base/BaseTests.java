package base;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pages.HomePage;

public class BaseTests {
	
	 
	//On this page are all the tests that will be run before and after each test and also driver configuration and page address//

	private static WebDriver driver;
	protected HomePage homePage;

	@BeforeAll
	public static void initialize() {
		System.setProperty("webdriver.chrome.driver", "src/test/resources/Webdrivers/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@BeforeEach
	public void uploadInitialPage() {
		driver.get("https://www.demoblaze.com/index.html");
		homePage = new HomePage(driver);
	}

	@AfterAll
	public static void finish() {
		driver.quit();
	}

}
