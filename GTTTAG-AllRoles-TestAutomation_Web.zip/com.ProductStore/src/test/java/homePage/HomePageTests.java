package homePage;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Test;

import base.BaseTests;
import pages.CheckoutPage;
import pages.OrderPage;
import pages.ProductPage;

public class HomePageTests extends BaseTests {
	 //On this page will be displayed all tests about the process//
	

	// Teste para navegar entre las categor�as y elegir el producto 


	/*@Test

	public void testValidateProductSonyVaio() {
		int index = 8;
		assertThat(homePage.getProductName(index), is("Sony vaio"));

	}

	@Test
	public void testValidateProductDell() {
		int index = 12;
		assertThat(homePage.getProductName(index), is("Dell i7 8gb"));

	}
*/
	ProductPage productPage;
	String productName_productPage;

	@Test
	public void validatingProduct() {
		int index = 0;
		String productNameHomePage = homePage.getProductName(index);
		String productpriceHomePage = homePage.getProductPrice(index);

		System.out.println(productNameHomePage);
		System.out.println(productpriceHomePage);

		productPage = homePage.clickProduct(index);

		String productNameProductPage = productPage.getProductName();
		String productPriceProductPage = productPage.getProductPrice();

		System.out.println(productNameProductPage);
		System.out.println(productPriceProductPage);

		assertThat(productNameHomePage.toUpperCase(), is(productNameProductPage.toUpperCase()));
		assertThat(productpriceHomePage, is(productPriceProductPage));



	}
	
	@Test
	public void testFinishOrder() {
		
		CheckoutPage checkoutPage = null;
		
		
		OrderPage orderPage = checkoutPage.clickToProceedOrder();
		
		//Validar valores del pedido
		
	}



}
